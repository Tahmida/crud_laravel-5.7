<?php $__env->startSection('title', "Editar o post {$post->title}"); ?>

<?php $__env->startSection('content'); ?>

<h1>Cadastrar post: <?php echo e($post->title); ?></h1>

<form action="<?php echo e(route('posts.update', $post->id)); ?>" method="post" enctype="multipart/form-data">
    <input type="hidden" name="_method" value="PUT">

    <?php echo $__env->make('posts._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>