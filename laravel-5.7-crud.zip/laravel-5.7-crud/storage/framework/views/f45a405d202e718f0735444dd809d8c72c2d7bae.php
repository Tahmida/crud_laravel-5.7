<?php $__env->startSection('title', 'Listagem dos posts'); ?>

<?php $__env->startSection('content'); ?>

<h1>
    Posts
    <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus-square"></i>
    </a>
</h1>

<?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       
        <div class="media-body">
            <table class="table table-striped table-bordered table-hover">
                    <thead class="table_head">
                    <tr>
                        <th>User Name</th>
                        <th>Post Title</th>
                        <th class="width-200">create date</th>
                        <th class="text-center">Action</th>
                    </tr>
                    </thead> 
                    <?php if($posts): ?>
                        <tbody>    
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr >
                                    <td><?php echo e($post->user->name); ?></td>
                                    <td><?php echo e($post->title); ?></td>
                                    <td><?php echo e($post->created_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('posts.destroy', $post->id)); ?>">Delete</a>|
                                        <a href="<?php echo e(route('posts.edit', $post->id)); ?>">Edit</a>
                                    </td>
                                </tr>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    <?php else: ?>
                        <tbody>
                            <tr>
                                <td>NO Data Found</td>
                            </tr>
                        </tbody>
                    <?php endif; ?>

            </table>
        </div>

    
  

    <?php echo $posts->links(); ?>

</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>