@extends('layouts.app')

@section('title', 'Listagem dos posts')

@section('content')

<h1>
    Posts
    <a href="{{ route('posts.create') }}" class="btn btn-primary">
        <i class="fas fa-plus-square"></i>
    </a>
</h1>

@include('includes.alerts')
       {{--  <div class="pull-left">
            @php
                $pathImage = url('imgs/posts/default.png');

                if ($post->image)
                    $pathImage = url("storage/posts/{$post->image}");
            @endphp
            <img src="{{ $pathImage }}" alt="{{ $post->title }}" class="img-circle" style="max-width: 60px; margin: 10px;">
        </div> --}}
        <div class="media-body">
            <table class="table table-striped table-bordered table-hover">
                    <thead class="table_head">
                    <tr>
                        <th>User Name</th>
                        <th>Post Title</th>
                        <th class="width-200">create date</th>
                        <th class="text-center">Action</th>
                    </tr>
                    </thead> 
                    @if($posts)
                        <tbody>    
                            @foreach($posts as $post)
                                <tr >
                                    <td>{{ $post->user->name }}</td>
                                    <td>{{ $post->title }}</td>
                                    <td>{{ $post->created_at }}</td>
                                    <td>
                                        <a href="{{ route('posts.destroy', $post->id) }}">Delete</a>|
                                        <a href="{{ route('posts.edit', $post->id) }}">Edit</a>
                                    </td>
                                </tr>  
                            @endforeach
                        </tbody>
                    @else
                        <tbody>
                            <tr>
                                <td>NO Data Found</td>
                            </tr>
                        </tbody>
                    @endif

            </table>
        </div>

    
  

    {!! $posts->links() !!}
</ul>

@endsection